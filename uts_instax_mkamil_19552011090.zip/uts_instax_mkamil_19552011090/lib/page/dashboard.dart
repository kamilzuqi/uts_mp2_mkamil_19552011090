part of 'pages.dart';

class Dashboard extends StatefulWidget {
  Dashboard({Key? key}) : super(key: key);

  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  List<ModelProduk> data = [];
  List<ModelProduk> dataSearch = [];

  @override
  void initState() {
    data = [
      ModelProduk(
          name: "Mint",
          colour: Color(0xff70b1a1),
          price: "50.00",
          image: 'assets/InstaxMini7plus_Mint_R.png'),
      ModelProduk(
          name: "Blue",
          colour: Color(0xff77a0c6),
          price: "53.00",
          image: 'assets/InstaxMini7plus_Blue_R.png'),
      ModelProduk(
          name: "Choral",
          colour: Color(0xffb0463c),
          price: "49.00",
          image: 'assets/InstaxMini7plus_Choral_R.png'),
      ModelProduk(
          name: "Lavender",
          colour: Color(0xff855f8c),
          price: "55.00",
          image: 'assets/InstaxMini7plus_Lavender_R.png'),
      ModelProduk(
          name: "Pink",
          colour: Color(0xffcf9496),
          price: "50.00",
          image: 'assets/InstaxMini7plus_Pink_R.png'),
    ];

    dataSearch = data;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        iconTheme: IconThemeData(color: Colors.black),
        title: Image.asset('assets/fujifilm-banner.png', height: 20),
        leading: IconButton(
          onPressed: () {},
          icon: Icon(Icons.menu),
        ),
        actions: [
          IconButton(
            onPressed: () {},
            icon: Icon(Icons.shopping_bag),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.all(10),
          child: Column(
            children: [
              TextField(
                style: TextStyle(color: Colors.white),
                onChanged: (text) {
                  text = text.toLowerCase();
                  setState(() {
                    data = dataSearch.where((val) {
                      var cariNama = val.name.toLowerCase();
                      return cariNama.contains(text);
                    }).toList();
                  });
                },
                decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(20.0),
                    ),
                    filled: true,
                    hintStyle: TextStyle(color: Colors.white),
                    hintText: "Search",
                    fillColor: Colors.black),
              ),
              ListView.builder(
                physics: const NeverScrollableScrollPhysics(),
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                itemCount: data.length,
                itemBuilder: (BuildContext context, int index) {
                  return CardProduk(
                    data[index],
                  );
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
