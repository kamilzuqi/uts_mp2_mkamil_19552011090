import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:uts_instax_mkamil_19552011090/models/modelProduk.dart';
import 'package:uts_instax_mkamil_19552011090/widget/cardProduk.dart';

part 'detail.dart';
part 'dashboard.dart';
part 'splash.dart';
