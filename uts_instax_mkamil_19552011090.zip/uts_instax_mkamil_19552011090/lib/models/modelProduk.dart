import 'dart:convert';

import 'package:flutter/material.dart';

ModelProduk modelProdukFromJson(String str) =>
    ModelProduk.fromJson(json.decode(str));

String modelProdukToJson(ModelProduk data) => json.encode(data.toJson());

class ModelProduk {
  ModelProduk({
    required this.name,
    required this.colour,
    required this.price,
    required this.image,
  });

  String name;
  Color colour;
  String price;
  String image;

  factory ModelProduk.fromJson(Map<String, dynamic> json) => ModelProduk(
        name: json["name"],
        colour: json["colour"],
        price: json["price"],
        image: json["image"],
      );

  Map<String, dynamic> toJson() => {
        "name": name,
        "colour": colour,
        "price": price,
        "image": image,
      };
}
